# Shenzhen Cyberpunk Scene Upgrade

- [ ] Add the Shenzhen cyberpunk night scene as a selectable particle model.
- [ ] Add neon skyline, tower, signage, and light-trail particle geometry with a night color palette.
- [ ] Improve gesture handling with clearer open-palm, fist, pinch, and hand-position feedback.
- [ ] Add a mobile-friendly camera permission and fallback interaction path.
- [ ] Validate the build and preview, then prepare a downloadable source archive.
- [ ] Save a final checkpoint and provide GitHub export and Publish-button instructions.

## Notes

- Keep all user-facing copy in English.
- Preserve the existing Christmas tree, Saturn, and heart models.
- Do not commit camera footage or other private user data.
- Publishing will be completed by the user through the project Management UI after the checkpoint is created.

## Status

- [ ] Implementation in progress
- [ ] Build validation complete
- [ ] Source archive prepared
- [ ] Final checkpoint saved
- [ ] Delivery report sent

> Design direction: high-rise Shenzhen skyline at night, electric cyan/magenta/amber neon, dense but readable particle forms, and responsive gesture-first interaction.

## Gesture upgrade request
- [ ] Map hand x/y movement to direct object translation and 3D tilt.
- [ ] Map palm depth to smooth shrink/enlarge scaling.
- [ ] Switch scenes only on a stable one-finger gesture.
- [ ] Add dynamic particle drift, shimmer, and depth animation.
- [ ] Add a minimizable control panel optimized for phone screens.
- [ ] Validate desktop and mobile previews, then save a checkpoint.

## Camera troubleshooting
- [ ] Distinguish sandbox no-device errors from real phone permission errors.
- [ ] Improve camera constraints and status messaging for HTTPS mobile use.
- [ ] Preserve mouse/touch fallback when preview has no camera.
- [ ] Validate build and save a camera-flow checkpoint.

## Wide skyline upgrade
- [ ] Expand Shenzhen geometry across a wider city footprint with more buildings.
- [ ] Add a 360-degree neon city presentation with deeper camera framing.
- [ ] Add illuminated Chinese building-name signage in the night scene.
- [ ] Increase horizontal hand-steering speed and rotation range.
- [ ] Validate desktop and phone framing, then save a checkpoint.

## Download packaging
- [ ] Create a combined GitHub-ready source archive.
- [ ] Create separate archives for client, runtime, configuration, and documentation files.
- [ ] Exclude node_modules, dist, logs, caches, and private camera data.
- [ ] Write upload instructions and verify archive contents.
