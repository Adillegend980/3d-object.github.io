# Shenzhen Cyberpunk Particle Lab — Design Direction

## Three stylistic approaches

### Theme Name: Electric Skyline
Very Brief Intro: A dense Shenzhen nightscape built from luminous particles, inspired by neon streets, high-rise silhouettes, and long-exposure light trails. The experience should feel energetic, urban, and spatial.
Probability: 0.07

### Theme Name: Pearl River Haze
Very Brief Intro: A quieter atmospheric interpretation with misty blue-black depth, sparse tower lights, and a calm gallery-like rhythm. The emotion is contemplative rather than explosive.
Probability: 0.04

### Theme Name: Signal District
Very Brief Intro: A high-contrast data-visualization aesthetic with modular blocks, scan lines, and geometric signage. The mood is technical, precise, and experimental.
Probability: 0.02

## Chosen approach: Electric Skyline

### Design Movement
Neo-futurist urbanism with references to cyberpunk city photography, long-exposure light trails, and generative digital installations.

### Core Principles
1. Build the skyline from recognizable vertical masses, not an abstract cloud.
2. Use cyan, magenta, and amber as signals of movement and life against a near-black blue night.
3. Keep controls sparse and legible so the particle field remains the visual focus.
4. Make gestures feel physical: open palms expand, fists contract, pinches switch scenes, and hand position steers the view.

### Color Philosophy
The background is a deep blue-black night that gives the particle field room to glow. Cyan represents active energy and the riverfront skyline, magenta marks signage and nightlife, and amber supplies warm windows and human scale. The ownable signature color is Shenzhen Neon Cyan: `#10F7FF`.

### Layout Paradigm
The particle field occupies the entire viewport. Controls sit in a narrow glass instrument panel at the upper-left, while the camera preview and gesture state stay anchored to the lower edge. The skyline should feel wider than the interface and should never be boxed into a central card.

### Signature Elements
A luminous central tower with a stepped crown, horizontal city light bands, and thin magenta/amber light trails appear throughout the Shenzhen scene. Small labels use a restrained technical tone rather than decorative copy.

### Interaction Philosophy
The interface should teach itself through live state feedback. A hand is not a cursor: it is a physical controller. Palm openness controls scale, hand position controls rotation, a pinch cycles scenes, and the UI reports the active gesture without blocking the artwork.

### Animation
Scene changes morph over roughly 0.8 seconds rather than snapping. Particle rotation follows the hand with damped easing. Light trails drift slowly, while interaction feedback should be quick and restrained. Respect reduced-motion preferences by reducing the morph and rotation intensity.

### Typography System
Use a clean system sans for controls and a slightly expanded uppercase treatment for small technical labels. Headlines are compact and confident; status copy is plain English and action-oriented.

### Brand Essence
Mirza Adil Beg Particle Lab is an interactive generative-art playground for curious visitors who want to shape a luminous world with their hands. Personality: **kinetic, atmospheric, precise**.

### Brand Voice
Headlines and buttons should sound like instrument labels, not marketing filler. Example lines: “Shape the skyline with your hand.” and “Pinch to switch scenes.”

### Wordmark & Logo
Use the existing project name as the product label, paired with a simple three-line skyline mark in the interface rather than relying on a default text-only logo.

### Signature Brand Color
Shenzhen Neon Cyan — `#10F7FF`.

## Style Decisions

- The cyberpunk treatment is limited to the particle scene, not every UI surface.
- The new city model must remain readable on phones and lower-powered devices.
- English is the only user-facing interface language.
