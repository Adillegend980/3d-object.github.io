/*
 * Design reminder: Electric Skyline / neo-futurist urbanism.
 * Let the particle field dominate, use Shenzhen Neon Cyan (#10F7FF), and keep controls sparse,
 * readable, and gesture-first across desktop and mobile.
 */
import { useEffect, useRef } from 'react';
import { startParticleExperience } from '@/lib/particleRuntime';

declare global {
  interface Window {
    __particleScripts?: Record<string, Promise<void> | undefined>;
  }
}

const THREE_URL = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
const ORBIT_CONTROLS_URL = 'https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js';
const CAMERA_UTILS_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js';
const HANDS_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js';

function loadScript(src: string) {
  window.__particleScripts ??= {};
  if (window.__particleScripts[src]) return window.__particleScripts[src];

  window.__particleScripts[src] = new Promise<void>((resolve, reject) => {
    const existing = document.querySelector(`script[src="${src}"]`);
    if (existing) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.crossOrigin = 'anonymous';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load ${src}`));
    document.head.appendChild(script);
  });

  return window.__particleScripts[src];
}

export default function Home() {
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const experienceRoot = rootRef.current!;
    if (!experienceRoot) return;

    let cleanup: () => void = () => {};
    let cancelled = false;

    async function boot() {
      try {
        await loadScript(THREE_URL);
        await Promise.all([loadScript(ORBIT_CONTROLS_URL), loadScript(CAMERA_UTILS_URL), loadScript(HANDS_URL)]);
        if (cancelled) return;
        cleanup = await startParticleExperience(experienceRoot, { loadScript });
      } catch (error) {
        console.warn('Particle experience failed to boot:', error);
        const loading = experienceRoot.querySelector('#loading');
        if (loading) loading.textContent = 'The experience could not load. Please refresh the page.';
      }
    }

    void boot();
    return () => {
      cancelled = true;
      cleanup();
    };
  }, []);

  return (
    <main ref={rootRef} id="particle-app" data-scene="tree">
      <style>{`
        :root {
          --night: #030712;
          --panel: rgba(6, 12, 25, 0.78);
          --panel-soft: rgba(11, 22, 42, 0.72);
          --text: #effbff;
          --muted: #8ca6b8;
          --signal: #10f7ff;
          --magenta: #ff2bd6;
          --amber: #ffbb58;
        }

        * { box-sizing: border-box; }

        html, body, #root, #particle-app {
          width: 100%;
          height: 100%;
          min-height: 100%;
          margin: 0;
        }

        body {
          overflow: hidden;
          background: var(--night);
          color: var(--text);
          font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        }

        #particle-app {
          position: relative;
          overflow: hidden;
          background:
            radial-gradient(circle at 76% 26%, rgba(16, 247, 255, 0.08), transparent 28%),
            radial-gradient(circle at 62% 84%, rgba(255, 43, 214, 0.08), transparent 25%),
            var(--night);
        }

        #particle-app[data-scene="shenzhen"] {
          background:
            radial-gradient(circle at 72% 22%, rgba(16, 247, 255, 0.14), transparent 26%),
            radial-gradient(circle at 35% 78%, rgba(255, 43, 214, 0.14), transparent 28%),
            linear-gradient(180deg, #030712 0%, #06152d 100%);
        }

        #canvas-container {
          position: absolute;
          inset: 0;
          z-index: 1;
        }

        #canvas-container canvas {
          display: block;
          width: 100%;
          height: 100%;
          touch-action: none;
        }

        .ui-panel {
          position: absolute;
          top: clamp(16px, 3vw, 28px);
          left: clamp(16px, 3vw, 28px);
          z-index: 10;
          width: min(334px, calc(100vw - 32px));
          padding: 22px;
          border: 1px solid rgba(125, 200, 225, 0.22);
          border-radius: 18px;
          background: linear-gradient(145deg, var(--panel), rgba(3, 7, 18, 0.68));
          box-shadow: 0 18px 70px rgba(0, 0, 0, 0.42), inset 0 1px 0 rgba(255, 255, 255, 0.06);
          backdrop-filter: blur(20px);
        }

        .panel-toggle {
          position: absolute;
          top: 10px;
          right: 10px;
          width: 30px;
          height: 30px;
          border: 1px solid rgba(16, 247, 255, 0.35);
          border-radius: 9px;
          color: var(--signal);
          background: rgba(16, 247, 255, 0.08);
          font-size: 20px;
          line-height: 1;
          cursor: pointer;
          transition: transform 160ms ease, background 160ms ease, border-color 160ms ease;
        }

        .panel-toggle:hover { background: rgba(16, 247, 255, 0.18); border-color: var(--signal); }
        .panel-toggle:active { transform: scale(0.93); }
        .ui-panel.collapsed { width: 54px; min-height: 54px; padding: 10px; }
        .ui-panel.collapsed > :not(#panel-toggle) { display: none; }

        .eyebrow {
          margin-bottom: 10px;
          color: var(--signal);
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.22em;
          text-transform: uppercase;
        }

        .ui-panel h1 {
          margin: 0;
          color: var(--text);
          font-size: clamp(22px, 3vw, 29px);
          font-weight: 650;
          letter-spacing: -0.04em;
          line-height: 1;
        }

        .intro {
          margin: 11px 0 20px;
          color: var(--muted);
          font-size: 13px;
          line-height: 1.55;
        }

        .control-group { margin-top: 18px; }

        .control-group label,
        .gesture-guide summary {
          display: block;
          margin-bottom: 8px;
          color: #a9c2ce;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }

        select {
          width: 100%;
          padding: 12px 13px;
          border: 1px solid rgba(125, 200, 225, 0.25);
          border-radius: 10px;
          outline: none;
          color: var(--text);
          background: rgba(255, 255, 255, 0.07);
          font-size: 14px;
          cursor: pointer;
        }

        select:focus-visible,
        button:focus-visible,
        input:focus-visible,
        summary:focus-visible {
          outline: 2px solid var(--signal);
          outline-offset: 3px;
        }

        option { color: #ffffff; background: #071225; }

        .color-picker-wrapper {
          display: flex;
          align-items: center;
          gap: 12px;
          color: var(--text);
          font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
          font-size: 13px;
        }

        input[type="color"] {
          width: 38px;
          height: 38px;
          padding: 0;
          border: 0;
          border-radius: 50%;
          background: transparent;
          cursor: pointer;
        }

        input[type="color"]::-webkit-color-swatch-wrapper { padding: 0; }
        input[type="color"]::-webkit-color-swatch {
          border: 2px solid rgba(255, 255, 255, 0.7);
          border-radius: 50%;
        }

        .status-box {
          min-height: 50px;
          margin-top: 20px;
          padding: 12px 13px;
          border-left: 3px solid rgba(255, 255, 255, 0.42);
          border-radius: 8px;
          color: #bac8d0;
          background: rgba(255, 255, 255, 0.055);
          font-size: 12px;
          line-height: 1.45;
        }

        .status-box.active {
          border-left-color: var(--signal);
          color: var(--signal);
          background: rgba(16, 247, 255, 0.07);
        }

        .camera-action {
          display: inline-flex;
          margin-top: 9px;
          padding: 7px 9px;
          border: 1px solid rgba(16, 247, 255, 0.38);
          border-radius: 7px;
          color: var(--signal);
          background: rgba(16, 247, 255, 0.08);
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          cursor: pointer;
        }

        .camera-action:hover { background: rgba(16, 247, 255, 0.16); }

        .gesture-guide {
          margin-top: 16px;
          border-top: 1px solid rgba(125, 200, 225, 0.16);
          padding-top: 14px;
        }

        .gesture-guide summary {
          margin: 0;
          cursor: pointer;
          list-style: none;
        }

        .gesture-guide summary::-webkit-details-marker { display: none; }
        .gesture-guide summary::after { content: "+"; float: right; color: var(--signal); }
        .gesture-guide[open] summary::after { content: "−"; }

        .gesture-guide p {
          margin: 11px 0 0;
          color: var(--muted);
          font-size: 12px;
          line-height: 1.65;
        }

        .top-right-controls {
          position: absolute;
          top: clamp(16px, 3vw, 28px);
          right: clamp(16px, 3vw, 28px);
          z-index: 10;
        }

        .btn {
          border: 1px solid rgba(125, 200, 225, 0.25);
          border-radius: 10px;
          padding: 11px 15px;
          color: var(--text);
          background: rgba(6, 12, 25, 0.7);
          box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.05);
          backdrop-filter: blur(16px);
          font-size: 12px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          cursor: pointer;
          transition: border-color 160ms ease, background 160ms ease, transform 160ms ease;
        }

        .btn:hover { border-color: var(--signal); background: rgba(16, 247, 255, 0.1); }
        .btn:active { transform: scale(0.97); }

        #webcam {
          position: absolute;
          right: clamp(16px, 3vw, 28px);
          bottom: clamp(16px, 3vw, 28px);
          z-index: 10;
          width: 168px;
          height: 126px;
          border: 1px solid rgba(16, 247, 255, 0.7);
          border-radius: 12px;
          object-fit: cover;
          transform: scaleX(-1);
          background: #02050d;
          box-shadow: 0 0 26px rgba(16, 247, 255, 0.1);
        }

        .camera-caption {
          position: absolute;
          right: calc(clamp(16px, 3vw, 28px) + 10px);
          bottom: calc(clamp(16px, 3vw, 28px) + 132px);
          z-index: 10;
          color: rgba(196, 234, 243, 0.8);
          font-size: 10px;
          letter-spacing: 0.12em;
          text-transform: uppercase;
        }

        #loading {
          position: absolute;
          top: 50%;
          left: 50%;
          z-index: 20;
          transform: translate(-50%, -50%);
          width: max-content;
          max-width: calc(100vw - 40px);
          padding: 13px 18px;
          border: 1px solid var(--signal);
          border-radius: 999px;
          color: var(--text);
          background: rgba(2, 7, 17, 0.88);
          box-shadow: 0 0 28px rgba(16, 247, 255, 0.14);
          font-size: 13px;
          text-align: center;
        }

        @media (max-width: 700px) {
          .ui-panel {
            top: 12px;
            left: 12px;
            width: min(310px, calc(100vw - 24px));
            padding: 16px;
          }

          .ui-panel.collapsed { width: 54px; min-height: 54px; padding: 10px; }

          .ui-panel h1 { font-size: 23px; }
          .intro { margin-bottom: 13px; font-size: 12px; }
          .control-group { margin-top: 13px; }
          .status-box { margin-top: 14px; }
          .gesture-guide { margin-top: 12px; padding-top: 11px; }
          #webcam { width: 112px; height: 84px; }
          .camera-caption { bottom: calc(clamp(16px, 3vw, 28px) + 90px); font-size: 8px; }
          .top-right-controls { top: auto; right: 12px; bottom: 112px; }
          .btn { padding: 9px 10px; font-size: 10px; }
        }

        @media (prefers-reduced-motion: reduce) {
          .btn { transition: none; }
        }
      `}</style>

      <div id="loading">Loading particle field…</div>
      <div id="canvas-container" aria-hidden="true" />
      <video id="webcam" autoPlay playsInline muted aria-label="Camera preview for hand gesture control" />
      <div className="camera-caption">Live hand input</div>

      <section className="ui-panel" aria-label="Particle controls">
        <button id="panel-toggle" className="panel-toggle" type="button" aria-expanded="true" aria-label="Minimize controls">−</button>
        <div className="eyebrow">Mirza Adil Beg // Cyberpunk Neural Core</div>
        <h1>Mirza Adil Beg's Neon Metropolis</h1>
        <p className="intro">Explore a wider 360° Shenzhen nightscape with denser high-rises and glowing Chinese district names. Move faster left or right to sweep the city around you.</p>

        <div className="control-group">
          <label htmlFor="model-select">3D Particle Model</label>
          <select id="model-select" defaultValue="tree">
            <option value="tree">Brilliant Christmas Tree</option>
            <option value="saturn">Mysterious Saturn</option>
            <option value="heart">Romantic Heart</option>
            <option value="shenzhen">Shenzhen Cyberpunk Night</option>
          </select>
        </div>

        <div className="control-group">
          <label htmlFor="particle-color">Particle Color</label>
          <div className="color-picker-wrapper">
            <input type="color" id="particle-color" defaultValue="#10F7FF" aria-label="Choose particle color" />
            <span id="color-hex">#10F7FF</span>
          </div>
        </div>

        <div className="status-box" id="gesture-status" role="status" aria-live="polite">
          Loading camera and hand controls…
        </div>
        <button id="camera-retry" className="camera-action" type="button">Enable camera</button>

        <details className="gesture-guide">
          <summary>Cyberpunk Gesture Protocol</summary>
          <p><strong>Move left/right:</strong> sweep the skyline fast through a full 360° view. <strong>Palm forward:</strong> enlarge. <strong>Palm backward:</strong> diminish. <strong>One raised finger:</strong> switch to the next object only. Drag with touch or mouse as a fallback.</p>
        </details>
      </section>

      <div className="top-right-controls">
        <button className="btn" id="btn-fullscreen" type="button">Fullscreen Mode</button>
      </div>
    </main>
  );
}
