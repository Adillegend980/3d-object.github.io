/*
 * Design reminder: Electric Skyline / neo-futurist urbanism.
 * Keep the particle field dominant, use Shenzhen Neon Cyan (#10F7FF) as the signature color,
 * and make gestures feel physical: open palm expands, fist contracts, pinch cycles scenes.
 */

type ThreeNamespace = any;
type Landmark = { x: number; y: number; z?: number };
type Cleanup = () => void;

type ParticleRuntimeOptions = {
  loadScript: (src: string) => Promise<void>;
};

const MODEL_NAMES = ['tree', 'saturn', 'heart', 'shenzhen'] as const;
type ModelName = (typeof MODEL_NAMES)[number];

function distance(a: Landmark, b: Landmark) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function mapLinear(value: number, inMin: number, inMax: number, outMin: number, outMax: number) {
  const normalized = clamp((value - inMin) / (inMax - inMin), 0, 1);
  return outMin + normalized * (outMax - outMin);
}

export async function startParticleExperience(root: HTMLElement, options: ParticleRuntimeOptions): Promise<Cleanup> {
  const THREE: ThreeNamespace = (window as any).THREE;
  const HandsConstructor: any = (window as any).Hands;
  const canvasContainer = root.querySelector('#canvas-container') as HTMLElement;
  const video = root.querySelector('#webcam') as HTMLVideoElement;
  const statusBox = root.querySelector('#gesture-status') as HTMLElement;
  const loading = root.querySelector('#loading') as HTMLElement;
  const modelSelect = root.querySelector('#model-select') as HTMLSelectElement;
  const colorInput = root.querySelector('#particle-color') as HTMLInputElement;
  const colorHex = root.querySelector('#color-hex') as HTMLElement;
  const fullscreenButton = root.querySelector('#btn-fullscreen') as HTMLButtonElement;
  const panel = root.querySelector('.ui-panel') as HTMLElement;
  const panelToggle = root.querySelector('#panel-toggle') as HTMLButtonElement;
  const cameraRetry = root.querySelector('#camera-retry') as HTMLButtonElement;

  if (!THREE || !canvasContainer) {
    if (loading) loading.textContent = '3D engine unavailable. Please refresh the page.';
    return () => undefined;
  }

  const isMobile = window.matchMedia('(max-width: 700px)').matches;
  const PARTICLE_COUNT = isMobile ? 15000 : 26000;
  const BASE_MODEL_SCALE = 1.7;
  const MIN_GESTURE_SCALE = 0.55;
  const MAX_GESTURE_SCALE = 1.65;

  const modelPositions: Record<ModelName, Float32Array> = {
    tree: new Float32Array(PARTICLE_COUNT * 3),
    saturn: new Float32Array(PARTICLE_COUNT * 3),
    heart: new Float32Array(PARTICLE_COUNT * 3),
    shenzhen: new Float32Array(PARTICLE_COUNT * 3),
  };

  function writePoint(array: Float32Array, index: number, x: number, y: number, z: number) {
    const i3 = index * 3;
    array[i3] = x;
    array[i3 + 1] = y;
    array[i3 + 2] = z;
  }

  function generateTree(array: Float32Array) {
    for (let i = 0; i < PARTICLE_COUNT; i += 1) {
      if (i < PARTICLE_COUNT * 0.08) {
        const angle = Math.random() * Math.PI * 2;
        const starWave = Math.abs(Math.sin(angle * 5));
        const radius = (1.8 + starWave * 3) * Math.sqrt(Math.random());
        writePoint(array, i, radius * Math.cos(angle), 20 + (Math.random() - 0.5) * 1.5, radius * Math.sin(angle) * 0.45);
      } else if (i < PARTICLE_COUNT * 0.92) {
        const height = Math.random() * 32 - 14;
        const layerNormalized = (height + 14) / 32;
        const layerProgress = (layerNormalized * 4) % 1;
        let baseRadius = (1 - layerNormalized) * 18;
        baseRadius *= Math.pow(layerProgress, 0.42);
        const angle = Math.random() * Math.PI * 2;
        const radius = Math.max(0, baseRadius * Math.sqrt(Math.random()) + (Math.random() - 0.5) * 2.5);
        writePoint(array, i, Math.cos(angle) * radius, height, Math.sin(angle) * radius);
      } else {
        const height = Math.random() * 5 - 19;
        const radius = Math.random() * 2.2;
        const angle = Math.random() * Math.PI * 2;
        writePoint(array, i, Math.cos(angle) * radius, height, Math.sin(angle) * radius);
      }
    }
  }

  function generateSaturn(array: Float32Array) {
    for (let i = 0; i < PARTICLE_COUNT; i += 1) {
      if (i < PARTICLE_COUNT * 0.42) {
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos(2 * Math.random() - 1);
        const radius = 11.5 * Math.cbrt(Math.random());
        const flatten = 0.82 + Math.random() * 0.06;
        writePoint(array, i, radius * Math.sin(phi) * Math.cos(theta), radius * Math.sin(phi) * Math.sin(theta) * flatten, radius * Math.cos(phi));
      } else {
        const ringBand = Math.random();
        const bandBase = ringBand < 0.22 ? 14.5 : ringBand < 0.48 ? 18.5 : ringBand < 0.72 ? 23.5 : 28.5;
        const ringRadius = bandBase + Math.random() * 3.5 + Math.sin(bandBase * 1.7 + i * 0.013) * 0.9;
        const theta = Math.random() * Math.PI * 2;
        const ripple = Math.sin(theta * 10 + ringRadius * 0.9) * 0.45 + Math.sin(theta * 23) * 0.18;
        writePoint(array, i, (ringRadius + ripple) * Math.cos(theta), (Math.random() - 0.5) * (0.45 + ringBand * 0.85), (ringRadius + ripple) * Math.sin(theta));
      }
    }
  }

  function generateHeart(array: Float32Array) {
    for (let i = 0; i < PARTICLE_COUNT; i += 1) {
      const t = Math.PI * 2 * Math.random();
      const u = Math.PI * (Math.random() - 0.5);
      const x = 16 * Math.pow(Math.sin(t), 3);
      const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
      const z = 6 * Math.sin(u) * (1 - Math.abs(Math.sin(t)));
      writePoint(array, i, x * 1.35, y * 1.35, z * 1.35);
    }
  }

  const shenzhenSignData: Array<{ x: number; y: number; z: number; text: string; tint: string; scale: number }> = [];

  function generateShenzhen(array: Float32Array) {
    type Building = { x: number; z: number; width: number; depth: number; height: number; central?: boolean; sign: string; tint: string };
    const signNames = ['深圳', '未来城', '华强北', '福田', '南山', '罗湖', '湾区', '云上', '深夜', '霓虹', '深港', '光之城', '科技园', '深圳湾', '龙岗', '前海'];
    const signTints = ['#10F7FF', '#FF2BD6', '#FFBB58', '#A77BFF'];
    const buildings: Building[] = [
      { x: 0, z: 0, width: 6.8, depth: 6.2, height: 52, central: true, sign: '深圳', tint: '#10F7FF' },
      { x: -9, z: 2, width: 4.8, depth: 4.8, height: 33, sign: '福田', tint: '#FF2BD6' },
      { x: 9, z: -1, width: 5.2, depth: 5, height: 38, sign: '南山', tint: '#FFBB58' },
      { x: -16, z: -2, width: 3.8, depth: 3.8, height: 25, sign: '罗湖', tint: '#A77BFF' },
      { x: 16, z: -3, width: 4.1, depth: 4, height: 28, sign: '湾区', tint: '#10F7FF' },
    ];

    for (let i = 0; i < 48; i += 1) {
      const angle = (i / 48) * Math.PI * 2 + (Math.random() - 0.5) * 0.18;
      const radius = 17 + Math.random() * 34;
      buildings.push({
        x: Math.cos(angle) * radius,
        z: Math.sin(angle) * radius,
        width: 2.1 + Math.random() * 4.2,
        depth: 2 + Math.random() * 4,
        height: 10 + Math.random() * 29,
        sign: signNames[i % signNames.length],
        tint: signTints[i % signTints.length],
      });
    }

    const baseY = -12;
    buildings.forEach((building, index) => {
      if (index === 0 || index % 2 === 0) {
        shenzhenSignData.push({
          x: building.x,
          y: baseY + building.height * 0.68,
          z: building.z,
          text: building.sign,
          tint: building.tint,
          scale: building.central ? 4.2 : 2.2 + (index % 3) * 0.35,
        });
      }
    });

    const cityPoint = () => (Math.random() < 0.16 ? buildings[0] : buildings[1 + Math.floor(Math.random() * (buildings.length - 1))]);

    for (let i = 0; i < PARTICLE_COUNT; i += 1) {
      const roll = i / PARTICLE_COUNT;

      if (roll < 0.60) {
        const building = cityPoint();
        const floors = Math.max(8, Math.floor(building.height * 2.15));
        const columns = Math.max(4, Math.floor(building.width * 2.1));
        const floor = Math.floor(Math.random() * floors);
        const column = Math.floor(Math.random() * columns);
        const level = floor / floors;
        const taper = building.central && level > 0.72 ? mapLinear(level, 0.72, 1, 1, 0.4) : 1;
        const width = building.width * taper;
        const depth = building.depth * taper;
        const y = baseY + (floor + 0.5) * (building.height / floors);
        const side = Math.floor(Math.random() * 4);
        const windowWidth = width / columns;
        let x = building.x - width / 2 + (column + 0.5) * windowWidth;
        let z = building.z - depth / 2 + (column + 0.5) * (depth / columns);
        if (side === 0) z = building.z - depth / 2;
        if (side === 1) z = building.z + depth / 2;
        if (side === 2) x = building.x - width / 2;
        if (side === 3) x = building.x + width / 2;
        writePoint(array, i, x + (Math.random() - 0.5) * 0.08, y + (Math.random() - 0.5) * 0.11, z + (Math.random() - 0.5) * 0.08);
      } else if (roll < 0.77) {
        const lane = Math.floor(Math.random() * 20);
        const y = -11 + lane * 0.94 + (Math.random() - 0.5) * 0.08;
        const x = -52 + Math.random() * 104;
        const z = 6.2 + Math.sin(x * 0.15 + lane) * 0.3;
        writePoint(array, i, x, y, z);
      } else if (roll < 0.87) {
        const centralCrown = Math.random() < 0.52;
        const y = centralCrown ? 34 + Math.random() * 26 : -11 + Math.random() * 4;
        const x = centralCrown ? (Math.random() - 0.5) * 2 : (Math.random() - 0.5) * 96;
        const z = centralCrown ? (Math.random() - 0.5) * 2 : (Math.random() - 0.5) * 82;
        writePoint(array, i, x, y, z);
      } else if (roll < 0.95) {
        const ring = Math.floor(Math.random() * 5);
        const theta = Math.random() * Math.PI * 2;
        const radius = 7 + ring * 3 + Math.sin(theta * 9) * 0.16;
        writePoint(array, i, Math.cos(theta) * radius, 24 + ring * 3.2, Math.sin(theta) * radius * 0.42);
      } else {
        const theta = Math.random() * Math.PI * 2;
        const radius = 44 + Math.random() * 18;
        writePoint(array, i, Math.cos(theta) * radius, 16 + Math.random() * 22, Math.sin(theta) * radius);
      }
    }
  }

  generateTree(modelPositions.tree);
  generateSaturn(modelPositions.saturn);
  generateHeart(modelPositions.heart);
  generateShenzhen(modelPositions.shenzhen);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(64, window.innerWidth / window.innerHeight, 0.1, 1400);
  camera.position.set(0, 9, 82);
  const renderer = new THREE.WebGLRenderer({ antialias: !isMobile, alpha: false, powerPreference: 'high-performance' });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobile ? 1.35 : 1.7));
  renderer.outputEncoding = THREE.sRGBEncoding;
  canvasContainer.appendChild(renderer.domElement);

  const controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.06;
  controls.enablePan = false;
  controls.minDistance = 42;
  controls.maxDistance = 150;
  controls.autoRotate = false;

  const geometry = new THREE.BufferGeometry();
  const currentPositions = new Float32Array(modelPositions.tree);
  const positionAttribute = new THREE.BufferAttribute(currentPositions, 3);
  geometry.setAttribute('position', positionAttribute);

  const material = new THREE.PointsMaterial({
    size: isMobile ? 0.29 : 0.34,
    color: new THREE.Color(colorInput?.value || '#10F7FF'),
    transparent: true,
    opacity: 0.92,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    sizeAttenuation: true,
  });
  const particlePhase = new Float32Array(PARTICLE_COUNT);
  const particleSpeed = new Float32Array(PARTICLE_COUNT);
  for (let i = 0; i < PARTICLE_COUNT; i += 1) {
    particlePhase[i] = Math.random() * Math.PI * 2;
    particleSpeed[i] = 0.65 + Math.random() * 1.15;
  }

  const particleSystem = new THREE.Points(geometry, material);
  scene.add(particleSystem);

  const signGroup = new THREE.Group();
  signGroup.visible = false;
  particleSystem.add(signGroup);
  const signMaterials: any[] = [];
  for (const sign of shenzhenSignData) {
    const labelCanvas = document.createElement('canvas');
    labelCanvas.width = 512;
    labelCanvas.height = 128;
    const labelContext = labelCanvas.getContext('2d');
    if (!labelContext) continue;
    labelContext.clearRect(0, 0, labelCanvas.width, labelCanvas.height);
    labelContext.font = '700 74px "Noto Sans CJK SC", "Microsoft YaHei", sans-serif';
    labelContext.textAlign = 'center';
    labelContext.textBaseline = 'middle';
    labelContext.shadowColor = sign.tint;
    labelContext.shadowBlur = 24;
    labelContext.fillStyle = sign.tint;
    labelContext.fillText(sign.text, labelCanvas.width / 2, labelCanvas.height / 2);
    labelContext.shadowBlur = 8;
    labelContext.fillStyle = '#FFFFFF';
    labelContext.fillText(sign.text, labelCanvas.width / 2, labelCanvas.height / 2);
    const labelTexture = new THREE.CanvasTexture(labelCanvas);
    labelTexture.needsUpdate = true;
    const labelMaterial = new THREE.SpriteMaterial({ map: labelTexture, transparent: true, depthWrite: false, opacity: 0.92 });
    const labelSprite = new THREE.Sprite(labelMaterial);
    labelSprite.position.set(sign.x, sign.y, sign.z);
    labelSprite.scale.set(sign.scale * 2.9, sign.scale * 0.74, 1);
    signGroup.add(labelSprite);
    signMaterials.push({ material: labelMaterial, texture: labelTexture });
  }

  scene.background = new THREE.Color(0x050505);
  scene.fog = new THREE.FogExp2(0x050505, 0.012);

  let activeModel: ModelName = 'tree';
  let targetGestureScale = 1;
  let gestureScale = 1;
  let targetRotationX = 0;
  let targetRotationY = 0;
  let targetPositionX = 0;
  let targetPositionY = 0;
  let targetPositionZ = 0;
  let baseParticleSize = isMobile ? 0.29 : 0.34;
  let oneFingerActive = false;
  let lastGesture = 'Waiting for hand gesture';
  let pinchCooldownUntil = 0;
  let animationFrame = 0;
  let handTimer = 0;
  let disposed = false;
  let mediaStream: MediaStream | null = null;
  let hands: any = null;
  let handProcessing = false;
  let pointerDown = false;
  let lastPointerX = 0;
  let lastPointerY = 0;

  function updateStatus(text: string, active = false) {
    if (!statusBox) return;
    statusBox.textContent = text;
    statusBox.classList.toggle('active', active);
  }

  function applySceneTheme(model: ModelName) {
    activeModel = model;
    const shenzhen = model === 'shenzhen';
    scene.background.set(shenzhen ? 0x030712 : 0x050505);
    scene.fog = new THREE.FogExp2(shenzhen ? 0x030712 : 0x050505, shenzhen ? 0.008 : 0.012);
    baseParticleSize = shenzhen ? (isMobile ? 0.24 : 0.29) : (isMobile ? 0.29 : 0.34);
    material.size = baseParticleSize;
    camera.position.set(0, shenzhen ? 12 : 6, shenzhen ? 96 : 58);
    controls.target.set(0, shenzhen ? 8 : 0, 0);
    signGroup.visible = shenzhen;
    if (panel) panel.dataset.scene = model;
    document.body.dataset.scene = model;
  }

  function setModel(model: ModelName, announce = true) {
    if (!modelPositions[model]) return;
    applySceneTheme(model);
    if (announce) updateStatus(`${model === 'shenzhen' ? 'Shenzhen Cyberpunk Night' : model[0].toUpperCase() + model.slice(1)} selected • morphing`, true);
  }

  function nextModel() {
    const index = MODEL_NAMES.indexOf(activeModel);
    const next = MODEL_NAMES[(index + 1) % MODEL_NAMES.length];
    setModel(next);
    if (modelSelect) modelSelect.value = next;
  }

  function handleGesture(landmarks: Landmark[]) {
    const wrist = landmarks[0];
    const thumbTip = landmarks[4];
    const indexPip = landmarks[6];
    const indexTip = landmarks[8];
    const middlePip = landmarks[10];
    const middleTip = landmarks[12];
    const ringPip = landmarks[14];
    const ringTip = landmarks[16];
    const pinkyPip = landmarks[18];
    const pinkyTip = landmarks[20];
    const middleBase = landmarks[9];
    const palmSize = Math.max(distance(wrist, middleBase), 0.06);
    const palmCenterX = (wrist.x + middleBase.x) / 2;
    const palmCenterY = (wrist.y + middleBase.y) / 2;

    const extensionRatios = [
      distance(indexTip, wrist) / Math.max(distance(indexPip, wrist), 0.01),
      distance(middleTip, wrist) / Math.max(distance(middlePip, wrist), 0.01),
      distance(ringTip, wrist) / Math.max(distance(ringPip, wrist), 0.01),
      distance(pinkyTip, wrist) / Math.max(distance(pinkyPip, wrist), 0.01),
    ];
    const extendedCount = extensionRatios.filter((ratio) => ratio > 1.18).length;
    const indexRaised = extensionRatios[0] > 1.22;
    const otherFingersFolded = extensionRatios.slice(1).every((ratio) => ratio < 1.16);
    const oneFinger = indexRaised && otherFingersFolded && distance(thumbTip, indexTip) / palmSize > 0.52;
    const pinchRatio = distance(thumbTip, indexTip) / palmSize;
    const fingertipSpread = [thumbTip, indexTip, middleTip, ringTip, pinkyTip]
      .map((tip) => distance(tip, { x: palmCenterX, y: palmCenterY }))
      .reduce((sum, value) => sum + value, 0) / 5;
    const openness = fingertipSpread / palmSize;
    const now = performance.now();
    const handX = 1 - palmCenterX;
    const depth = mapLinear(palmSize, 0.1, 0.27, 0, 1);
    const depthScale = mapLinear(palmSize, 0.1, 0.27, MIN_GESTURE_SCALE, MAX_GESTURE_SCALE);

    // Direct translation: move the hand left/right/up/down and the object follows.
    targetPositionX = clamp((handX - 0.5) * 48, -24, 24);
    targetPositionY = clamp((0.5 - palmCenterY) * 26, -12, 12);
    targetPositionZ = mapLinear(depth, 0, 1, -8, 14);
    targetRotationY = clamp((handX - 0.5) * Math.PI * 2, -Math.PI, Math.PI);
    targetRotationX = clamp((palmCenterY - 0.5) * 1.8, -1.4, 1.4);

    if (oneFinger) {
      targetGestureScale = depthScale;
      if (!oneFingerActive && now > pinchCooldownUntil) {
        oneFingerActive = true;
        pinchCooldownUntil = now + 1000;
        nextModel();
      }
      lastGesture = 'One finger • switch object';
    } else {
      oneFingerActive = false;
      if (extendedCount >= 3 && openness > 2.05) {
        targetGestureScale = depthScale;
        lastGesture = palmSize > 0.2 ? 'Palm forward • enlarge' : 'Palm back • diminish';
      } else if (extendedCount <= 1 && openness < 1.85) {
        targetGestureScale = mapLinear(depth, 0, 1, MIN_GESTURE_SCALE, 0.9);
        lastGesture = 'Fist • contract';
      } else if (pinchRatio < 0.48) {
        targetGestureScale = mapLinear(depth, 0, 1, 0.7, 1.1);
        lastGesture = 'Pinch • precision mode';
      } else {
        targetGestureScale = depthScale;
        lastGesture = 'Hand steer • 3D tracking';
      }
    }

    updateStatus(`${lastGesture} | X ${targetPositionX.toFixed(1)} • Scale ${targetGestureScale.toFixed(2)}x`, true);
  }

  function processHands() {
    if (disposed || !hands || !video || handProcessing || video.readyState < 2) return;
    handProcessing = true;
    hands.send({ image: video }).catch(() => undefined).finally(() => {
      handProcessing = false;
    });
  }

  async function startCameraAndHands() {
    if (!navigator.mediaDevices?.getUserMedia) {
      updateStatus('Camera API unavailable • use mouse or touch to steer', false);
      if (cameraRetry) cameraRetry.textContent = 'Camera unavailable';
      if (loading) loading.remove();
      return;
    }

    try {
      mediaStream?.getTracks().forEach((track) => track.stop());
      mediaStream = null;
      const preferredConstraints: MediaStreamConstraints = {
        audio: false,
        video: {
          facingMode: { ideal: 'user' },
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
      };
      try {
        mediaStream = await navigator.mediaDevices.getUserMedia(preferredConstraints);
      } catch (firstError: any) {
        if (firstError?.name !== 'OverconstrainedError' && firstError?.name !== 'NotFoundError') throw firstError;
        mediaStream = await navigator.mediaDevices.getUserMedia({ audio: false, video: true });
      }
      video.srcObject = mediaStream;
      await video.play();
      if (cameraRetry) cameraRetry.textContent = 'Camera active';
      updateStatus('Camera ready • open palm, fist, or one finger to control', true);

      if (!HandsConstructor) {
        updateStatus('Camera ready • hand model unavailable • use mouse or touch to steer', true);
        if (cameraRetry) cameraRetry.textContent = 'Camera active';
        if (loading) loading.remove();
        return;
      }

      hands = new HandsConstructor({
        locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
      });
      hands.setOptions({
        maxNumHands: 1,
        modelComplexity: isMobile ? 0 : 1,
        minDetectionConfidence: 0.58,
        minTrackingConfidence: 0.58,
      });
      hands.onResults((results: any) => {
        if (results.multiHandLandmarks?.length) {
          handleGesture(results.multiHandLandmarks[0]);
        } else {
          updateStatus('Camera ready • show one hand to control the particles', false);
        }
      });
      processHands();
    } catch (error: any) {
      console.warn('Camera access was not granted:', error);
      const name = error?.name;
      const message = name === 'NotFoundError'
        ? 'No camera device detected in this preview • open the published HTTPS site on your phone'
        : name === 'NotAllowedError'
          ? 'Camera permission blocked • allow camera for this site, then tap Enable camera'
          : name === 'SecurityError'
            ? 'Camera needs HTTPS • use the published site, not a local preview'
            : 'Camera unavailable • mouse or touch controls are active';
      updateStatus(message, false);
      if (cameraRetry) cameraRetry.textContent = 'Enable camera';
    } finally {
      if (loading) loading.remove();
    }
  }

  function onResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobile ? 1.35 : 1.7));
  }

  function onPointerDown(event: PointerEvent) {
    pointerDown = true;
    lastPointerX = event.clientX;
    lastPointerY = event.clientY;
    renderer.domElement.setPointerCapture?.(event.pointerId);
  }

  function onPointerMove(event: PointerEvent) {
    if (!pointerDown) return;
    const dx = event.clientX - lastPointerX;
    const dy = event.clientY - lastPointerY;
    lastPointerX = event.clientX;
    lastPointerY = event.clientY;
    targetPositionX = clamp(targetPositionX + dx * 0.055, -12, 12);
    targetPositionY = clamp(targetPositionY - dy * 0.045, -9, 9);
    targetPositionZ = clamp(targetPositionZ + Math.abs(dx + dy) * 0.012, -4, 7);
    targetRotationY = clamp(targetRotationY + dx * 0.006, -1.6, 1.6);
    targetRotationX = clamp(targetRotationX + dy * 0.004, -1.2, 1.2);
    lastGesture = 'Pointer steer • 3D drag';
    updateStatus(`${lastGesture} | Move to translate`, true);
  }

  function onPointerUp() {
    pointerDown = false;
  }

  function animate() {
    if (disposed) return;
    animationFrame = window.requestAnimationFrame(animate);
    const time = performance.now();
    const seconds = time * 0.001;
    gestureScale += (targetGestureScale - gestureScale) * 0.14;
    particleSystem.position.x += (targetPositionX - particleSystem.position.x) * 0.16;
    particleSystem.position.y += (targetPositionY - particleSystem.position.y) * 0.16;
    particleSystem.position.z += (targetPositionZ - particleSystem.position.z) * 0.16;
    particleSystem.rotation.x += (targetRotationX - particleSystem.rotation.x) * 0.12;
    particleSystem.rotation.y += (targetRotationY - particleSystem.rotation.y) * 0.12;
    particleSystem.rotation.z += (activeModel === 'shenzhen' ? 0.0008 : 0.0012) + Math.sin(seconds * 1.2) * 0.0005;
    const sceneScale = activeModel === 'shenzhen' ? 1.2 : BASE_MODEL_SCALE;
    particleSystem.scale.setScalar(sceneScale * gestureScale);
    material.size = baseParticleSize * (1 + Math.sin(seconds * 3.3) * 0.08);

    const target = modelPositions[activeModel];
    const dynamicAmount = activeModel === 'shenzhen' ? 0.16 : 0.1;
    for (let i = 0; i < currentPositions.length; i += 3) {
      const particleIndex = i / 3;
      const phase = particlePhase[particleIndex];
      const speed = particleSpeed[particleIndex];
      const wave = Math.sin(seconds * speed * 2.1 + phase + target[i + 2] * 0.04);
      const drift = Math.cos(seconds * speed * 1.4 + phase * 1.7);
      const targetX = target[i] + wave * dynamicAmount;
      const targetY = target[i + 1] + drift * dynamicAmount * 0.7;
      const targetZ = target[i + 2] + Math.sin(seconds * speed * 1.8 + phase) * dynamicAmount * 1.25;
      currentPositions[i] += (targetX - currentPositions[i]) * 0.075;
      currentPositions[i + 1] += (targetY - currentPositions[i + 1]) * 0.075;
      currentPositions[i + 2] += (targetZ - currentPositions[i + 2]) * 0.075;
    }
    positionAttribute.needsUpdate = true;
    controls.update();
    renderer.render(scene, camera);

    if (hands && performance.now() > handTimer) {
      handTimer = performance.now() + (isMobile ? 115 : 75);
      processHands();
    }
  }

  modelSelect?.addEventListener('change', () => setModel(modelSelect.value as ModelName));
  colorInput?.addEventListener('input', () => {
    material.color.set(colorInput.value);
    if (colorHex) colorHex.textContent = colorInput.value.toUpperCase();
  });
  fullscreenButton?.addEventListener('click', () => {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen?.();
    else document.exitFullscreen?.();
  });
  function onPanelToggle() {
    const collapsed = panel?.classList.toggle('collapsed') ?? false;
    panelToggle.setAttribute('aria-expanded', String(!collapsed));
    panelToggle.textContent = collapsed ? '＋' : '−';
    panelToggle.setAttribute('aria-label', collapsed ? 'Show controls' : 'Minimize controls');
    updateStatus(collapsed ? 'Controls minimized • gesture-first mode active' : 'Controls expanded • choose a particle model', true);
  }
  panelToggle?.addEventListener('click', onPanelToggle);
  cameraRetry?.addEventListener('click', () => {
    cameraRetry.disabled = true;
    cameraRetry.textContent = 'Requesting…';
    void startCameraAndHands().finally(() => {
      if (!disposed && cameraRetry.textContent === 'Requesting…') cameraRetry.textContent = 'Enable camera';
      if (!disposed) cameraRetry.disabled = false;
    });
  });
  window.addEventListener('resize', onResize);
  renderer.domElement.addEventListener('pointerdown', onPointerDown);
  renderer.domElement.addEventListener('pointermove', onPointerMove);
  renderer.domElement.addEventListener('pointerup', onPointerUp);
  renderer.domElement.addEventListener('pointercancel', onPointerUp);

  applySceneTheme('shenzhen');
  if (modelSelect) modelSelect.value = 'shenzhen';
  updateStatus('Loading camera and hand controls…', false);
  animate();

  // Camera is requested only after the first 3D frame is visible, so the page feels immediate.
  window.setTimeout(() => {
    if (!disposed) void startCameraAndHands();
  }, 180);

  return () => {
    disposed = true;
    window.cancelAnimationFrame(animationFrame);
    window.removeEventListener('resize', onResize);
    renderer.domElement.removeEventListener('pointerdown', onPointerDown);
    renderer.domElement.removeEventListener('pointermove', onPointerMove);
    renderer.domElement.removeEventListener('pointerup', onPointerUp);
    renderer.domElement.removeEventListener('pointercancel', onPointerUp);
    panelToggle?.removeEventListener('click', onPanelToggle);
    cameraRetry?.replaceWith(cameraRetry.cloneNode(true));
    mediaStream?.getTracks().forEach((track) => track.stop());
    hands?.close?.();
    controls.dispose?.();
    geometry.dispose();
    material.dispose();
    signMaterials.forEach(({ material: signMaterial, texture }: any) => {
      signMaterial.dispose?.();
      texture.dispose?.();
    });
    renderer.dispose();
    renderer.domElement.remove();
  };
}

export { MODEL_NAMES };
