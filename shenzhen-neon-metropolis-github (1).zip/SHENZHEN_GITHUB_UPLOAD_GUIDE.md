# Mirza Adil Beg — Shenzhen Neon Metropolis

This package contains the final Shenzhen cyberpunk particle website from checkpoint `cab3f4f1`. It includes the wider 360° particle skyline, faster horizontal hand steering, palm-depth scaling, one-finger scene switching, mobile controls, and glowing Chinese building-name signage.

## Which file should you download?

| File | Purpose |
|---|---|
| `shenzhen-neon-metropolis-github.zip` | **Recommended.** Complete GitHub-ready source tree in one archive. |
| `shenzhen-neon-metropolis-client-source.zip` | Frontend client files only. |
| `shenzhen-neon-metropolis-gesture-runtime.zip` | Main interactive page, gesture runtime, styles, and HTML entry file. |
| `shenzhen-neon-metropolis-project-config.zip` | Project configuration, package manifest, server/shared placeholders, and build files. |
| `SHA256SUMS.txt` | Integrity hashes for the ZIP archives. |
| `file-manifest.txt` | List of files included in the combined archive. |

## Upload the combined archive to GitHub using the website

Download `shenzhen-neon-metropolis-github.zip` and extract it on your computer. Open the extracted `mirza-adil-beg-neon-metropolis` folder, select all of its contents, and create a new GitHub repository named something similar to `mirza-adil-beg-neon-metropolis` or `mirza-adil-beg-cyberpunk-city`.

In the new repository, choose **Add file → Upload files**, drag the extracted project contents into the upload area, and commit the files to the `main` branch. Upload the contents of the extracted project folder, not the outer folder itself, so that `package.json`, `client/`, `server/`, and `vite.config.ts` appear at the repository root.

For the connected project route, open the Management UI, choose **Settings → GitHub**, select **Export to GitHub**, and use the same repository name. The combined ZIP is useful for keeping a local copy or uploading manually; the connected export is preferable because it preserves the project structure automatically.

## Run the project locally after downloading

From the repository root, install dependencies and start the development server:

```bash
pnpm install
pnpm dev
```

To verify a production build, run:

```bash
pnpm check
pnpm build
```

The camera requires a real camera device and a secure HTTPS origin. The cloud preview may report that no camera device exists, so test hand tracking from the published HTTPS site on your phone. Mouse and touch steering remain available as a fallback.

## Important packaging notes

The combined archive intentionally excludes `node_modules`, `dist`, development logs, caches, internal checkpoint metadata, and private camera footage. Dependencies are restored by running `pnpm install`; generated production output is recreated by `pnpm build`.

The project uses the visible branding **Mirza Adil Beg's Neon Metropolis**. Suggested repository names are `mirza-adil-beg-neon-metropolis`, `mirza-adil-beg-cyberpunk-city`, and `shenzhen-neon-particle-city`.
